print("What is the lowest possible number from the list?")
lowest=int(input())
print("What is the highest possible number from the list?")
highest=int(input())
import random
print("Your random number is:",random.randint(lowest,highest))
