print ("This program will calculate the amount you need to pay for a tip if there are multiple people")
print("Please inset your bill's total or the dish price")
x = input ()
print ("Please enter the percentage of your tip")
y = input ()
print("Please enter the amount of people in your group")
z = input ()
a = (int(x)*int(y))/100;
a= a/int(z)

print (int(a))

