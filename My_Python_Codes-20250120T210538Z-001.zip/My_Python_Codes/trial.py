print("What is the base of your triangle?")
base=input()
print("What is the height of your triangle?")
height=input()
half=2/4
Area=int(base)*int(height)*float(half)
#this is my first program after starting codecamp.org
print("The area of your triangle is", Area)
