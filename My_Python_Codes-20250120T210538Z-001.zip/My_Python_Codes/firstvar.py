def redbull():
    print ("Red Bull gives you wiiiings")
    max ("Charles Leclerc is the best Ferrari driver")
redbull()
print(max,"Charles Leclerc is the best Ferrari driver")