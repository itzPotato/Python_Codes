print ("Enter your Base:")
x = input()
print ("Enter your height:")
y = input()
z = int(x)* int(y)/2
print ("The area of your triangle is " + str(z))
